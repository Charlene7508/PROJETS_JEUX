

Pour installer les dependances mlx:
cd mlx/mlx_CLXV
chmod +x *.sh
make

puis:
pip install python/dist/mlx-2.2-py3-none-any.whl

Un package Python installable a besoin de :

Un fichier pyproject.toml — la carte d'identité du package (nom, version, dépendances, où trouver le code)
Un mazegen/__init__.py — qui expose proprement les fonctions à l'extérieur (tu l'as déjà, mais on va peut-être l'enrichir)
Une commande de build — qui transforme tout ça en un fichier .whl installable (comme tu l'as fait pour la MLX, mais version plus légère, pas de compilation C ici)

# A-Maze-ing

*A personal reimplementation of the 42 School "A-Maze-ing" project — solo, from scratch, including the maze generation engine, a terminal display, and a playable graphical version built with the MiniLibX (MLX).*

## Description

This project generates a maze using a recursive backtracking algorithm, computes the shortest path between an entry and an exit with a breadth-first search (BFS), and displays the result in two ways:

- a **terminal mode**, showing the generated maze and its solution automatically;
- a **playable graphical mode** (MLX), where you control a character and navigate the maze yourself, with an optional hint (the shortest path) and a personal "C" pattern hidden in the center of the maze instead of the original "42".

This is a personal follow-up to the official 42 School "A-Maze-ing" project (done in pair with a teammate), built solo afterward to learn the maze generation and pathfinding algorithms that were handled by the teammate the first time around.

## Features

- Maze generation with a recursive backtracker (guarantees a perfect maze: exactly one path between any two cells).
- Shortest path resolution with BFS.
- A custom "C" pattern (closed, isolated cells), centered in the maze, replacing the original "42" pattern.
- Hexadecimal encoding of the maze to a text output file.
- Terminal display: full walls, entry/exit, solution path, 3 color palettes, interactive menu.
- Graphical display (MLX): the same maze, playable with arrow keys, with a movable character, collision detection against walls, a win message, and the same interactive options (regenerate, show/hide hint, change colors, quit).

## Instructions

### Requirements

- Python 3.10+
- A virtual environment (recommended)

### Setup

```bash
python3 -m venv venv
source venv/bin/activate
make install
```

### Configuration

Edit `config.txt` to set the maze parameters:

```
WIDTH=20
HEIGHT=15
ENTRY=0,0
EXIT=19,14
OUTPUT_FILE=maze.txt
PERFECT=True
```

### Run — terminal mode

```bash
make run
```

Generates a maze, writes it to the output file, and displays it (with the solution) in the terminal, with an interactive menu:

- `1` — Re-generate a new maze
- `2` — Show / hide the shortest path
- `3` — Change the color palette
- `4` — Quit

### Run — graphical / playable mode (MLX)

The MLX graphical mode requires building the MiniLibX Python module from the sources provided by 42 School (`mlx_CLXV`), and a graphical display environment (available by default on Linux desktops; on WSL, requires WSLg on Windows 11).

**One-time setup:**

```bash
make install-mlx
```

**Run the game:**

```bash
make run-mlx
```

Controls:

- **Arrow keys** — move the character through the maze
- `1` — Re-generate a new maze
- `2` — Show / hide the shortest path (hint)
- `3` — Change the color palette
- `4` — Quit

Reach the exit to win — a message appears, and you can regenerate a new maze from the menu.

### Lint

```bash
make lint          # flake8 + mypy
make lint-strict   # flake8 + mypy --strict
```

## Project structure

```
.
├── a_maze_ing.py           # entry point (terminal mode pipeline)
├── config.txt               # default configuration
├── mazegen/
│   ├── mazegen.py           # generation engine: create_grid, remove_wall,
│   │                        # generate_maze (backtracker), BFS, shortest_path
│   └── config_loader.py     # config file parsing and validation
├── output/
│   ├── encoder.py           # hexadecimal encoding, output file writing
│   ├── display.py           # terminal display (walls, colors, path)
│   ├── menu.py               # terminal interactive menu
│   ├── mlx_display.py       # graphical + playable version (MLX)
│   └── assets/               # player and exit images
├── tests/
│   └── fixtures.py          # fixed test mazes used during development
└── Makefile
```

## Technical choices

**Generation algorithm — recursive backtracker (iterative, stack-based).** Chosen because it always produces a perfect maze (no loops, exactly one path between any two cells) — which also guarantees, for free, that no area can be wider than 2 cells. Implemented iteratively (with an explicit stack) rather than with real recursion, to avoid Python's recursion depth limit on large mazes.

**Pathfinding — BFS (breadth-first search).** Explores the maze level by level from the entry; the first time the exit is dequeued, the path found is guaranteed to be the shortest one. A `came_from` dictionary records, for each visited cell, which cell it was discovered from — the path is reconstructed by walking this dictionary backward from the exit to the entry.

**Custom "C" pattern.** Replaces the original 42-specific "42" pattern. A fixed set of 5 relative coordinates is centered in the grid; those cells are added to the `visited` set *before* generation starts, so the backtracker never enters or opens a wall around them — they remain fully closed and isolated, exactly like the pattern requirement in the original subject.

**Graphical rendering (MLX).** The maze is drawn in a single pass into an in-memory image buffer (`mlx_new_image` + direct buffer writes), then sent to the window in one call — this is drastically faster than calling `mlx_pixel_put` per pixel, which became a real performance issue once player movement required frequent redraws.

## Resources

- 42 School official "A-Maze-ing" subject (project structure, output file format, "42" pattern requirement — adapted here into a personal "C" pattern).
- MiniLibX documentation (`man/` pages and `mlx.h` header, provided with the `mlx_CLXV` sources) and the provided `simple_test.py` / `mlxtest.py` examples, used as reference for the exact Python wrapper syntax (image buffers, key hooks, color format).
- Python documentation on `collections.deque` (queue for BFS) and bitwise/type hint syntax.

### Use of AI

AI (Claude) was used throughout as a **learning assistant**, not as a code generator. For each new concept (recursive backtracking, BFS, coordinate systems, MLX image buffers, keyboard hooks), it explained the underlying idea first, then guided the implementation step by step through questions and corrections — all code was written by hand and debugged personally, so every part of the project can be explained and modified independently. AI also helped diagnose MLX-specific issues (color channel order, buffer initialization, image layering) that had no clear public documentation, and assisted with performance optimization once the naive pixel-by-pixel rendering became too slow for real-time player movement.

## What could be improved

- The MLX rendering still redraws the whole maze buffer on every player move; a further optimization would cache the background and only patch the moved region.
- The reusable engine (`mazegen`) could be packaged as an installable module (`pip install`-able), as required by the original 42 subject, for reuse in future projects (e.g. a Pac-Man-style game built on the same maze engine).
- Text centering in the MLX window is currently estimated manually (no font-metrics API available in this MLX wrapper) — a more robust approach would measure actual rendered text width if the library ever exposes it.